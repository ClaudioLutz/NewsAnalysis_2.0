"""Platform-specific utilities for MCP."""
