VERSION = "6.7.6"

if __name__ == "__main__":
    print(VERSION, end="")  # noqa: T201
